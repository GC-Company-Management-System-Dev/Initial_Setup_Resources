package com.yeogi.infoseccert;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class InfoseccertApplicationTests {

	@Test
	void contextLoads() {
	}

}
